/*package com.ibm.test;

import java.io.IOException;
import java.util.HashMap;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ibm.utilities.ExcelUtil;
import com.ibm.utilities.PropertiesFileHandler;

//jars would be in the link
// https://drive.google.com/open?id=1Oa7AzFN8nQapvatjRToU_bwDgpf18QKI
public class BaseTest {
	
	//Use properties to solve the simple test cases. 
	@Test
	public void testcase1() throws IOException
	{
		String file="./TestData/magentodata.properties";
		PropertiesFileHandler propFileHandler = new PropertiesFileHandler();
		HashMap<String, String> data= propFileHandler.getPropertiesAsMap(file);
	}
	
	//excel data using dataprovider
	//run and check	
	//sends data in excel one by one
    @Test(dataProvider = "data")
    public void testcase2(String user, String pwd){
    		System.out.println(user);
    		System.out.println(pwd);
    }

    @DataProvider(name="data")
    public Object[][] data() throws IOException {
        return ExcelUtil.DataTable("./TestData/TestData.xlsx","LoginData");
    }
}
*/