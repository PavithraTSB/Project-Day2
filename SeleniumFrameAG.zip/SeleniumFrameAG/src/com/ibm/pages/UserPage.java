package com.ibm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UserPage 
{
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[2]")WebElement catalog;
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[4]")WebElement banner;
	@FindBy(how=How.XPATH,using="(//table[@id='dataTableExample2']/tbody/tr/td[6])[1]")WebElement table;
	@FindBy(how=How.LINK_TEXT,using="Edit")WebElement edit;
	@FindBy(how=How.XPATH,using="//select[@name='dataTableExample2_length']")WebElement dropDown;

	By validation =By.xpath("//table[@id='dataTableExample2']/tbody/tr");
	
	WebDriverWait wait;
	WebDriver driver;
	
	public UserPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public UserPage clickCatalog()
	{
		catalog.click();
		return this;
	}
	public UserPage clickBanner()
	{
		banner.click();
		return this;
	}
	public UserPage navigateToTable()
	{
		table.click();
		return this;
	}
	public EditBannerPage edit()
	{
		edit.click();
		return new EditBannerPage(driver, wait);
	}
	public void clickDropDown()
	   {
		   WebElement entries = dropDown;
	       Select se=new Select(entries);
			se.selectByVisibleText("All");
			
			
	   }
	   public String getPageSrcForModifiedRow()
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(validation));
			
			return driver.getPageSource();
		}
   
	
}


