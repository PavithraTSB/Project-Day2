package com.ibm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductPage {

	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[2]")WebElement catalog;
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[6]")WebElement products;
	@FindBy(how=How.XPATH,using="//table[@id='dataTableExample2']/tbody/tr[2]/td[9]")WebElement table;
	@FindBy(how=How.LINK_TEXT,using="Edit")WebElement edit;
	WebDriverWait wait;
	WebDriver driver;
	
	public ProductPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public void clickCatalog()
	{
		catalog.click();
	}
	
	public void clickProducts()
	{
		products.click();
	}
	public void actionTable()
	{
		table.click();
	}
	public void clickEdit()
	{
		edit.click();
	}
}
